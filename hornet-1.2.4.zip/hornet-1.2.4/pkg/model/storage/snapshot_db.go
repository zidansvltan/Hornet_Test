package storage

import (
	"github.com/pkg/errors"

	"github.com/iotaledger/hive.go/kvstore"
	"github.com/iotaledger/hornet/pkg/common"
)

func (s *Storage) configureSnapshotStore(snapshotStore kvstore.KVStore) error {
	snapshotStore, err := snapshotStore.WithRealm([]byte{common.StorePrefixSnapshot})
	if err != nil {
		return err
	}

	s.snapshotStore = snapshotStore
	return nil
}

func (s *Storage) storeSnapshotInfo(snapshot *SnapshotInfo) error {

	if err := s.snapshotStore.Set([]byte("snapshotInfo"), snapshot.Bytes()); err != nil {
		return errors.Wrap(NewDatabaseError(err), "failed to store snapshot info")
	}

	return nil
}

func (s *Storage) readSnapshotInfo() (*SnapshotInfo, error) {
	value, err := s.snapshotStore.Get([]byte("snapshotInfo"))
	if err != nil {
		if !errors.Is(err, kvstore.ErrKeyNotFound) {
			return nil, errors.Wrap(NewDatabaseError(err), "failed to retrieve snapshot info")
		}
		return nil, nil
	}

	info, err := SnapshotInfoFromBytes(value)
	if err != nil {
		return nil, errors.Wrap(NewDatabaseError(err), "failed to convert snapshot info")
	}
	return info, nil
}

func (s *Storage) storeSolidEntryPoints(points *SolidEntryPoints) error {
	if points.IsModified() {

		if err := s.snapshotStore.Set([]byte("solidEntryPoints"), points.Bytes()); err != nil {
			return errors.Wrap(NewDatabaseError(err), "failed to store solid entry points")
		}

		points.SetModified(false)
	}

	return nil
}

func (s *Storage) readSolidEntryPoints() (*SolidEntryPoints, error) {
	value, err := s.snapshotStore.Get([]byte("solidEntryPoints"))
	if err != nil {
		if !errors.Is(err, kvstore.ErrKeyNotFound) {
			return nil, errors.Wrap(NewDatabaseError(err), "failed to retrieve solid entry points")
		}
		return nil, nil
	}

	points, err := SolidEntryPointsFromBytes(value)
	if err != nil {
		return nil, errors.Wrap(NewDatabaseError(err), "failed to convert solid entry points")
	}
	return points, nil
}
