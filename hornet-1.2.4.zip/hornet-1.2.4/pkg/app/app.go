package app

// AppInfo provides informations about the app.
type AppInfo struct {
	Name                string
	Version             string
	LatestGitHubVersion string
}
