package dashboard

import (
	"context"

	"github.com/iotaledger/hive.go/events"
	"github.com/iotaledger/hornet/pkg/model/hornet"
	"github.com/iotaledger/hornet/pkg/model/milestone"
	"github.com/iotaledger/hornet/pkg/model/storage"
	"github.com/iotaledger/hornet/pkg/shutdown"
	"github.com/iotaledger/hornet/pkg/tipselect"
	"github.com/iotaledger/hornet/pkg/whiteflag"
	coordinatorPlugin "github.com/iotaledger/hornet/plugins/coordinator"
)

const (
	VisualizerIDLength = 7
)

// vertex defines a vertex in a DAG.
type vertex struct {
	ID           string   `json:"id"`
	Parents      []string `json:"parents"`
	IsSolid      bool     `json:"is_solid"`
	IsReferenced bool     `json:"is_referenced"`
	IsMilestone  bool     `json:"is_milestone"`
	IsTip        bool     `json:"is_tip"`
}

// metainfo signals that metadata of a given message changed.
type metainfo struct {
	ID string `json:"id"`
}

// confirmationinfo signals confirmation of a milestone msg with a list of exluded msgs in the past cone.
type confirmationinfo struct {
	ID          string   `json:"id"`
	ExcludedIDs []string `json:"excluded_ids"`
}

// tipinfo holds information about whether a given message is a tip or not.
type tipinfo struct {
	ID    string `json:"id"`
	IsTip bool   `json:"is_tip"`
}

func runVisualizer() {

	onReceivedNewMessage := events.NewClosure(func(cachedMsg *storage.CachedMessage, _ milestone.Index, _ milestone.Index) {
		cachedMsg.ConsumeMessageAndMetadata(func(msg *storage.Message, metadata *storage.MessageMetadata) { // message -1
			if !deps.SyncManager.IsNodeAlmostSynced() {
				return
			}

			parentsHex := make([]string, len(msg.Parents()))
			for i, parent := range msg.Parents() {
				parentsHex[i] = parent.ToHex()[:VisualizerIDLength]
			}

			hub.BroadcastMsg(
				&Msg{
					Type: MsgTypeVertex,
					Data: &vertex{
						ID:           msg.MessageID().ToHex(),
						Parents:      parentsHex,
						IsSolid:      metadata.IsSolid(),
						IsReferenced: metadata.IsReferenced(),
						IsMilestone:  false,
						IsTip:        false,
					},
				},
			)
		})
	})

	onMessageSolid := events.NewClosure(func(cachedMsgMeta *storage.CachedMetadata) {
		cachedMsgMeta.ConsumeMetadata(func(metadata *storage.MessageMetadata) { // meta -1

			if !deps.SyncManager.IsNodeAlmostSynced() {
				return
			}

			hub.BroadcastMsg(
				&Msg{
					Type: MsgTypeSolidInfo,
					Data: &metainfo{
						ID: metadata.MessageID().ToHex()[:VisualizerIDLength],
					},
				},
			)
		})
	})

	onReceivedNewMilestone := events.NewClosure(func(cachedMilestone *storage.CachedMilestone) {
		defer cachedMilestone.Release(true) // milestone -1

		if !deps.SyncManager.IsNodeAlmostSynced() {
			return
		}

		hub.BroadcastMsg(
			&Msg{
				Type: MsgTypeMilestoneInfo,
				Data: &metainfo{
					ID: cachedMilestone.Milestone().MessageID.ToHex()[:VisualizerIDLength],
				},
			},
		)
	})

	// show checkpoints as milestones in the coordinator node
	onIssuedCheckpointMessage := events.NewClosure(func(_ int, _ int, _ int, messageID hornet.MessageID) {
		if !deps.SyncManager.IsNodeAlmostSynced() {
			return
		}

		hub.BroadcastMsg(
			&Msg{
				Type: MsgTypeMilestoneInfo,
				Data: &metainfo{
					ID: messageID.ToHex()[:VisualizerIDLength],
				},
			},
		)
	})

	onMilestoneConfirmed := events.NewClosure(func(confirmation *whiteflag.Confirmation) {
		if !deps.SyncManager.IsNodeAlmostSynced() {
			return
		}

		excludedIDs := make([]string, len(confirmation.Mutations.MessagesExcludedWithConflictingTransactions))
		for i, messageID := range confirmation.Mutations.MessagesExcludedWithConflictingTransactions {
			excludedIDs[i] = messageID.MessageID.ToHex()[:VisualizerIDLength]
		}

		hub.BroadcastMsg(
			&Msg{
				Type: MsgTypeConfirmedInfo,
				Data: &confirmationinfo{
					ID:          confirmation.MilestoneMessageID.ToHex()[:VisualizerIDLength],
					ExcludedIDs: excludedIDs,
				},
			},
		)
	})

	onTipAdded := events.NewClosure(func(tip *tipselect.Tip) {
		if !deps.SyncManager.IsNodeAlmostSynced() {
			return
		}

		hub.BroadcastMsg(
			&Msg{
				Type: MsgTypeTipInfo,
				Data: &tipinfo{
					ID:    tip.MessageID.ToHex()[:VisualizerIDLength],
					IsTip: true,
				},
			},
		)
	})

	onTipRemoved := events.NewClosure(func(tip *tipselect.Tip) {
		if !deps.SyncManager.IsNodeAlmostSynced() {
			return
		}

		hub.BroadcastMsg(
			&Msg{
				Type: MsgTypeTipInfo,
				Data: &tipinfo{
					ID:    tip.MessageID.ToHex()[:VisualizerIDLength],
					IsTip: false,
				},
			},
		)
	})

	if err := Plugin.Daemon().BackgroundWorker("Dashboard[Visualizer]", func(ctx context.Context) {
		deps.Tangle.Events.ReceivedNewMessage.Hook(onReceivedNewMessage)
		defer deps.Tangle.Events.ReceivedNewMessage.Detach(onReceivedNewMessage)
		deps.Tangle.Events.MessageSolid.Hook(onMessageSolid)
		defer deps.Tangle.Events.MessageSolid.Detach(onMessageSolid)
		deps.Tangle.Events.ReceivedNewMilestone.Hook(onReceivedNewMilestone)
		defer deps.Tangle.Events.ReceivedNewMilestone.Detach(onReceivedNewMilestone)
		if cooEvents := coordinatorPlugin.Events(); cooEvents != nil {
			cooEvents.IssuedCheckpointMessage.Hook(onIssuedCheckpointMessage)
			defer cooEvents.IssuedCheckpointMessage.Detach(onIssuedCheckpointMessage)
		}
		deps.Tangle.Events.MilestoneConfirmed.Hook(onMilestoneConfirmed)
		defer deps.Tangle.Events.MilestoneConfirmed.Detach(onMilestoneConfirmed)

		if deps.TipSelector != nil {
			deps.TipSelector.Events.TipAdded.Hook(onTipAdded)
			defer deps.TipSelector.Events.TipAdded.Detach(onTipAdded)
			deps.TipSelector.Events.TipRemoved.Hook(onTipRemoved)
			defer deps.TipSelector.Events.TipRemoved.Detach(onTipRemoved)
		}

		<-ctx.Done()

		Plugin.LogInfo("Stopping Dashboard[Visualizer] ...")
		Plugin.LogInfo("Stopping Dashboard[Visualizer] ... done")
	}, shutdown.PriorityDashboard); err != nil {
		Plugin.LogPanicf("failed to start worker: %s", err)
	}
}
